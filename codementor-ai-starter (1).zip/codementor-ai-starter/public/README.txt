Place public assets (logo, icons, images) here. Files are served from the site root.
