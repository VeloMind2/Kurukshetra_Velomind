import { useState } from "react";
import {
  Activity, BookOpen, BrainCircuit, Bug, CheckCircle2, ChevronRight,
  Code2, GraduationCap, LayoutDashboard, Lightbulb, Map, Menu, Search,
  Settings, Target, TrendingUp, X
} from "lucide-react";

type Page = "Overview" | "Adaptive Assessment" | "Concept Map" | "Learning Autopsy" | "Bug Mutation Lab";

const navItems: { label: Page; icon: typeof LayoutDashboard }[] = [
  { label: "Overview", icon: LayoutDashboard },
  { label: "Adaptive Assessment", icon: Target },
  { label: "Concept Map", icon: Map },
  { label: "Learning Autopsy", icon: BrainCircuit },
  { label: "Bug Mutation Lab", icon: Bug },
];

const pageDescriptions: Record<Page, string> = {
  "Overview": "Your programming journey, at a glance.",
  "Adaptive Assessment": "Practice questions matched to your current skill level.",
  "Concept Map": "Explore how programming concepts connect.",
  "Learning Autopsy": "Understand recurring mistakes and how to improve.",
  "Bug Mutation Lab": "Find the bug, explain the cause, and strengthen your logic.",
};

function App() {
  const [activePage, setActivePage] = useState<Page>("Overview");
  const [mobileNav, setMobileNav] = useState(false);
  const [answered, setAnswered] = useState(false);
  const [selected, setSelected] = useState("");
  const [search, setSearch] = useState("");

  const choosePage = (page: Page) => {
    setActivePage(page);
    setMobileNav(false);
    setAnswered(false);
    setSelected("");
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><Code2 size={23} /></div>
          <div><strong>CodeMentor<span> AI</span></strong><small>LEARN • PRACTICE • GROW</small></div>
          <button className="icon-button close-menu" onClick={() => setMobileNav(false)} aria-label="Close menu"><X size={19} /></button>
        </div>
        <div className="workspace-label">LEARNING SPACE</div>
        <nav className="navigation">
          {navItems.map(({ label, icon: Icon }) => (
            <button key={label} className={`nav-item ${activePage === label ? "active" : ""}`} onClick={() => choosePage(label)}>
              <Icon size={18} /><span>{label}</span>{activePage === label && <ChevronRight size={16} className="nav-chevron" />}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="mentor-card">
            <div className="mentor-icon"><Lightbulb size={18} /></div>
            <strong>Need a hint?</strong>
            <p>Small steps lead to big breakthroughs.</p>
            <button onClick={() => choosePage("Adaptive Assessment")}>Practice now <ChevronRight size={15} /></button>
          </div>
          <button className="nav-item settings-item" onClick={() => alert("Settings demo: connect profile settings in a future version.")}><Settings size={18} /><span>Settings</span></button>
          <div className="profile">
            <div className="avatar">ST</div><div><strong>Student</strong><small>Beginner · Level 2</small></div>
            <GraduationCap size={18} className="profile-cap" />
          </div>
        </div>
      </aside>

      {mobileNav && <button className="mobile-overlay" onClick={() => setMobileNav(false)} aria-label="Close navigation" />}
      <main className="main-content">
        <header className="topbar">
          <button className="icon-button menu-button" onClick={() => setMobileNav(true)} aria-label="Open menu"><Menu size={21} /></button>
          <div className="breadcrumbs">Workspace <span>/</span> <strong>{activePage}</strong></div>
          <div className="topbar-actions">
            <label className="search-box"><Search size={16} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search learning..." /></label>
            <div className="top-avatar">ST</div>
          </div>
        </header>

        <section className="page-content">
          <div className="welcome-row">
            <div><div className="eyebrow"><span className="status-dot" /> YOUR PERSONAL LEARNING SPACE</div><h1>{activePage === "Overview" ? "Welcome back, Student!" : activePage}</h1><p>{pageDescriptions[activePage]}</p></div>
            <div className="date-chip"><Activity size={15} /> Learning mode <span>● Active</span></div>
          </div>

          {activePage === "Overview" && (
            <>
              <div className="hero-card">
                <div className="hero-copy"><div className="hero-tag"><BrainCircuit size={14} /> YOUR AI LEARNING COMPANION</div><h2>Build skills.<br /><span>One concept at a time.</span></h2><p>Personalized practice helps you find gaps, learn from mistakes, and grow your coding confidence.</p><button className="primary-button" onClick={() => choosePage("Adaptive Assessment")}>Continue learning <ChevronRight size={17} /></button></div>
                <div className="hero-art"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="code-window"><div className="window-dots"><i /><i /><i /></div><code><span>const</span> skills = [<br />&nbsp; <em>"practice"</em>,<br />&nbsp; <em>"curiosity"</em>,<br />&nbsp; <em>"progress"</em><br />];<br /><b>learn</b>(skills);</code></div><div className="floating-check"><CheckCircle2 size={21} /></div></div>
              </div>
              <div className="section-heading"><div><h2>Your progress</h2><p>A snapshot of your learning activity</p></div><button className="text-button" onClick={() => alert("Progress report is demo data.")}>View report <ChevronRight size={15} /></button></div>
              <div className="stats-grid">
                <StatCard icon={<TrendingUp size={19} />} tone="blue" label="Mastery score" value="68%" note="+8% this week" />
                <StatCard icon={<CheckCircle2 size={19} />} tone="green" label="Questions solved" value="24" note="6 this week" />
                <StatCard icon={<Target size={19} />} tone="purple" label="Concepts practiced" value="8" note="2 in progress" />
                <StatCard icon={<Activity size={19} />} tone="orange" label="Learning streak" value="4 days" note="Keep it going!" />
              </div>
              <div className="lower-grid">
                <section className="panel">
                  <div className="panel-heading"><div><h3>Focus areas</h3><p>Topics to practice next</p></div><span className="soft-badge">Personalized</span></div>
                  <FocusRow title="Loops" subtitle="Iteration & control flow" percent={42} color="purple" />
                  <FocusRow title="Arrays" subtitle="Indexing & collections" percent={58} color="blue" />
                  <FocusRow title="Functions" subtitle="Parameters & return values" percent={76} color="green" />
                </section>
                <section className="panel recommendation-panel">
                  <div className="recommendation-icon"><BookOpen size={20} /></div><span className="recommend-label">RECOMMENDED NEXT</span><h3>Master the loop</h3><p>Try a short set of loop questions to strengthen your understanding of iteration.</p><div className="lesson-meta"><span><Target size={14} /> 5 questions</span><span>~10 min</span></div><button className="secondary-button" onClick={() => choosePage("Adaptive Assessment")}>Start practice <ChevronRight size={16} /></button>
                </section>
              </div>
            </>
          )}

          {activePage === "Adaptive Assessment" && (
            <section className="panel assessment-panel">
              <div className="panel-heading"><div><span className="soft-badge">QUESTION 1 · EASY</span><h3 className="question-title">Understand the loop</h3><p>Choose the output of this code snippet.</p></div><div className="question-icon"><Target size={22} /></div></div>
              <pre className="code-block"><code><span>for</span> i <span>in</span> range(3):{"\n"}    print(i)</code></pre>
              <div className="answer-list">{["1 2 3", "0 1 2", "0 1 2 3", "The code has an error"].map((option) => <button key={option} className={`answer-option ${selected === option ? "selected" : ""}`} onClick={() => { setSelected(option); setAnswered(false); }}><span className="answer-radio">{selected === option ? "●" : ""}</span>{option}</button>)}</div>
              {answered && <div className={`feedback ${selected === "0 1 2" ? "correct" : "incorrect"}`}>{selected === "0 1 2" ? "Correct! range(3) produces 0, 1, and 2." : "Not quite. In Python, range(3) starts at 0 and stops before 3."}</div>}
              <button className="primary-button" disabled={!selected} onClick={() => setAnswered(true)}>Check answer <ChevronRight size={16} /></button>
              <p className="demo-note">Demo assessment: this sample question uses a fixed rule, not a connected AI model.</p>
            </section>
          )}

          {activePage === "Concept Map" && (
            <section className="panel concept-panel"><div className="panel-heading"><div><h3>Programming concept map</h3><p>Follow the path from foundations to advanced topics.</p></div><Map size={21} /></div><div className="concept-flow">{[["01","Variables","Foundation"],["02","Conditions","Decisions"],["03","Loops","Iteration"],["04","Arrays","Collections"],["05","Functions","Reusable code"]].map((c,i)=><div className="concept-step" key={c[0]}><div className={`concept-node node-${i+1}`}><small>{c[0]}</small><strong>{c[1]}</strong><span>{c[2]}</span></div>{i<4 && <div className="concept-connector"><ChevronRight size={20} /></div>}</div>)}</div><div className="concept-foot"><Lightbulb size={18} /><span>Suggested path: strengthen each concept before moving to the next one.</span></div></section>
          )}

          {activePage === "Learning Autopsy" && (
            <section className="panel"><div className="panel-heading"><div><h3>Learning Autopsy</h3><p>Example patterns to help you reflect on mistakes.</p></div><BrainCircuit size={22} /></div><div className="mistake-list"><Mistake title="Loop boundary confusion" type="Logic error" count="3 examples" detail="Review where loops start and stop, especially exclusive end ranges." tone="purple" /><Mistake title="Array index out of range" type="Indexing error" count="2 examples" detail="Remember that the last valid index is usually length − 1." tone="orange" /><Mistake title="Missing return value" type="Function error" count="1 example" detail="Check whether a function needs to return a result or only print it." tone="blue" /></div><p className="demo-note">These are illustrative examples, not analysis of real submissions.</p></section>
          )}

          {activePage === "Bug Mutation Lab" && (
            <section className="panel"><div className="panel-heading"><div><h3>Bug Mutation Lab</h3><p>Spot the problem in this modified code.</p></div><Bug size={22} /></div><div className="challenge-banner"><span className="soft-badge">DEBUGGING CHALLENGE</span><h3>Why does this loop skip a number?</h3><p>Inspect the code and select the likely issue.</p></div><pre className="code-block"><code><span>for</span> i <span>in</span> range(1, 5):{"\n"}    print(i + 1)</code></pre><div className="answer-list">{["The loop starts at 1", "The printed value is increased by 1", "The loop uses range", "There is no issue"].map((option) => <button key={option} className={`answer-option ${selected === option ? "selected" : ""}`} onClick={() => { setSelected(option); setAnswered(false); }}><span className="answer-radio">{selected === option ? "●" : ""}</span>{option}</button>)}</div>{answered && <div className="feedback correct">Think about the difference between the loop variable and the value printed. This challenge is a demo; review the output to confirm your answer.</div>}<button className="primary-button" disabled={!selected} onClick={() => setAnswered(true)}>Review answer <ChevronRight size={16} /></button></section>
          )}

          <footer className="footer"><span>© 2026 CodeMentor AI</span><span>Learn at your pace <span className="footer-heart">♥</span></span><span>Hackathon prototype · Demo data</span></footer>
        </section>
      </main>
    </div>
  );
}

function StatCard({ icon, tone, label, value, note }: { icon: React.ReactNode; tone: string; label: string; value: string; note: string }) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><span className="stat-label">{label}</span><strong className="stat-value">{value}</strong><span className={`stat-note ${tone}`}>{note}</span></div>;
}

function FocusRow({ title, subtitle, percent, color }: { title: string; subtitle: string; percent: number; color: string }) {
  return <div className="focus-row"><div className="focus-top"><div><strong>{title}</strong><small>{subtitle}</small></div><strong>{percent}%</strong></div><div className="progress-track"><div className={`progress-fill ${color}`} style={{ width: `${percent}%` }} /></div></div>;
}

function Mistake({ title, type, count, detail, tone }: { title: string; type: string; count: string; detail: string; tone: string }) {
  return <div className="mistake-row"><div className={`mistake-symbol ${tone}`}><Bug size={19} /></div><div className="mistake-content"><div className="mistake-title-row"><strong>{title}</strong><span className="soft-badge">{type}</span></div><p>{detail}</p><small>{count} · Suggested practice available</small></div></div>;
}

export default App;